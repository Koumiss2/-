#ifndef BTAB_H
#define BTAB_H

#include <QDialog>
#include <QSqlTableModel>
#include <QString>
namespace Ui {
class Btab;
}

class Btab : public QDialog
{
    Q_OBJECT

public:
    explicit Btab(QWidget *parent = nullptr);
    ~Btab();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_tableView_clicked(const QModelIndex &index);

private:
    Ui::Btab *ui;
    QSqlTableModel *model1;
    int rowCnt;
};

#endif // BTAB_H
