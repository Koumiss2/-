#include "btab.h"
#include "ui_btab.h"

Btab::Btab(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Btab)
{
    setWindowFlag(Qt::FramelessWindowHint);
    ui->setupUi(this);

    model1 = new  QSqlTableModel(this);
    model1->setTable("theBill");
    model1->select();
    ui->tableView->setModel(model1);
}

Btab::~Btab()
{
    delete ui;
}

void Btab::on_pushButton_clicked()
{
    model1->insertRow(model1->rowCount());
}


void Btab::on_pushButton_2_clicked()
{
    model1->removeRow(rowCnt);
}


void Btab::on_tableView_clicked(const QModelIndex &index)
{
    rowCnt = index.row();
}

